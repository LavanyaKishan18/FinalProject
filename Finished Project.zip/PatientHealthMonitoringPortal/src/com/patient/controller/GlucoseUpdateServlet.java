package com.patient.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.patient.bo.PatientBO;
import com.patient.dao.PatientDAO;
import com.patient.model.Glucose;

@WebServlet("/GlucoseUpdateServlet")
public class GlucoseUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String patientId = (String)(session.getAttribute("uId"));
		System.out.println(patientId);
		String timeOfTheDay=request.getParameter("ptime");
		System.out.println(timeOfTheDay);
		String bloodGlucoseLevel=request.getParameter("pglucose");
		System.out.println(bloodGlucoseLevel);
		Glucose g=new Glucose();
		g.setPatientId(Integer.parseInt((patientId)));
		g.setTimeOfTheDay(timeOfTheDay);
		g.setBloodGlucoseLevel(bloodGlucoseLevel);
		PatientBO pbo=new PatientBO();
		int status=pbo.updateGlucose(g);
		if(status!=0){
			
			RequestDispatcher rd=request.getRequestDispatcher("g.html");
			HttpSession hs=request.getSession();
			hs.setAttribute("glucose", bloodGlucoseLevel);
			rd.forward(request, response);
			
	}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
