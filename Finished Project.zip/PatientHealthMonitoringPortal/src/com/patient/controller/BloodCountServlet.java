package com.patient.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.patient.dao.PatientDAO;
import com.patient.model.BloodCount;
import com.patient.model.Glucose;

/**
 * Servlet implementation class BloodCountServlet
 */
@WebServlet("/BloodCountServlet")
public class BloodCountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		String patientId = (String)(session.getAttribute("uId"));
		System.out.println(patientId);
		String timeOfTheDay=request.getParameter("ptime");
		System.out.println(timeOfTheDay);
		String rbcCount=request.getParameter("prbccount");
		System.out.println(rbcCount);
		String wbcCount=request.getParameter("pwbccount");
		System.out.println(wbcCount);
		String plateletCount=request.getParameter("pplateletcount");
		System.out.println(plateletCount);
		BloodCount bc=new BloodCount();
		bc.setPatientId(Integer.parseInt(patientId));
		bc.setTimeOfTheDay(timeOfTheDay);
		bc.setRbcCount(rbcCount);
		bc.setWbcCount(wbcCount);
		bc.setPlateletCount(plateletCount);
		PatientDAO pdao=new PatientDAO();
		int status=0;
		try {
			status = pdao.addBloodCount(bc);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(status!=0){
			
			RequestDispatcher rd=request.getRequestDispatcher("b.html");
			rd.forward(request, response);
	}else{
		RequestDispatcher rd=request.getRequestDispatcher("bloodcount.jsp");
		rd.forward(request, response);
	}
		
	}


	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
