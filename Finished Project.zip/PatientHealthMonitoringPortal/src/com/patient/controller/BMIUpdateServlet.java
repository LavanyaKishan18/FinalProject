package com.patient.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.patient.bo.PatientBO;
import com.patient.dao.PatientDAO;
import com.patient.model.BMI;

@WebServlet("/BMIUpdateServlet")
public class BMIUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
				double height = Double.parseDouble(request.getParameter("pheight"));
				//System.out.println(height);
				
				double weight = Double.parseDouble(request.getParameter("pweight"));
				//System.out.println(weight);
				HttpSession session = request.getSession();
				String userid = (String)(session.getAttribute("uId"));
				System.out.println("servlet"+" "+userid);
				double bmi = (((weight) / (height * height)))*10000;
				BMI b = new BMI();
				b.setHeight(height);
				b.setWeight(weight);
				b.setId(userid);
				b.setBmi(bmi);
				PatientBO pbo = new PatientBO();
				int status = pbo.updateBMI(b);
				System.out.println("My Status "+status);
				if(status!=0){
					RequestDispatcher rd = request.getRequestDispatcher("BMIDisplayServlet");
					HttpSession hs=request.getSession();
					hs.setAttribute("height", height);
					hs.setAttribute("weight", weight);
					rd.forward(request, response);
					
				}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
