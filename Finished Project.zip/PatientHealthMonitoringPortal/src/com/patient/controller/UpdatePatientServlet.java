package com.patient.controller;


import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.patient.dao.PatientDAO;
import com.patient.model.Patient;

/**
 * Servlet implementation class UpdatePatientServlet
 */
@WebServlet("/UpdatePatientServlet")
public class UpdatePatientServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstName=request.getParameter("pfirstname");
		System.out.println(firstName);
		String lastName=request.getParameter("plastname");
		System.out.println(lastName);
		String age=request.getParameter("page");
		System.out.println(age);
		String gender=request.getParameter("pgender");
		System.out.println(gender);
		String contactNumber=request.getParameter("pcontactnumber");
		System.out.println(contactNumber);
		String emailAddress=request.getParameter("pemail");
		System.out.println(emailAddress);
		String city=request.getParameter("pcity");
		System.out.println(city);
		String state=request.getParameter("pstate");
		System.out.println(state);
		String userID=request.getParameter("pid");
		System.out.println(userID);
		String password=request.getParameter("ppassword");
		System.out.println(password);
		Patient p=new Patient();
		p.setFirstName(firstName);
		p.setLastName(lastName);
		p.setAge(Integer.parseInt(age));
		p.setGender(gender);
		p.setContactNumber(contactNumber);
		p.setEmailAddress(emailAddress);
		p.setCity(city);
		p.setState(state);
		p.setUserId(userID);
		p.setPassword(password);
		
		PatientDAO pdao=new PatientDAO();
		int status=pdao.updatePatient(p);
		if(status!=0){
			RequestDispatcher rd=request.getRequestDispatcher("update.html");
			rd.forward(request, response);
		}
		else{
			RequestDispatcher rd=request.getRequestDispatcher("edit.jsp");
			rd.forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
