package com.patient.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.patient.dao.PatientDAO;
import com.patient.model.BMI;
import com.patient.model.Diabetics;


@WebServlet("/DiabeticsDsisplayServlet")
public class DiabeticsDsisplayServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			PatientDAO pdao=new PatientDAO();
			HttpSession session = request.getSession();
			String uid = (String) session.getAttribute("uId");
			System.out.println("My UID id "+uid);
			Diabetics dia = pdao.displayDia(uid);
			System.out.println("this is from servlet");
			System.out.println(dia);
			System.out.println("This is from Servlet ends here");
			
			if(dia!=null){
				RequestDispatcher rd=request.getRequestDispatcher("diabeticsdisplay.jsp");
				request.setAttribute("diabetics",dia);
				rd.forward(request, response);
			}
			
			
			
			} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
