package com.patient.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.patient.dao.PatientDAO;
import com.patient.model.Diabetics;

@WebServlet("/DiabeticsServlet")
public class DiabeticsServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();

		String userid=request.getParameter("pid");
		System.out.println("servlet"+userid);
		PatientDAO pdao = new PatientDAO();
		Diabetics dia = new Diabetics();
		dia = pdao.Diabetics(userid);
		int status=0;
		try {
			status = pdao.DiabeticsInsert(dia);
			if (status != 0) {
				RequestDispatcher rd = request
						.getRequestDispatcher("DiabeticsDsisplayServlet");
				rd.forward(request, response);
			} 
		} catch (Exception e) {
			RequestDispatcher rd = request
					.getRequestDispatcher("DiabeticsDsisplayServlet");
			rd.forward(request, response);
			
		}
	

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

	}

}
