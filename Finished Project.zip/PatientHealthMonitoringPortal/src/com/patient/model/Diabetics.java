package com.patient.model;

public class Diabetics {
	private String userId;
	private double height;
	private double weight;
	private int age;
	private String glucoseLevel;
	private String diabeticsLevel;
	private String date;
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public double getHeight() {
		return height;
	}
	public void setHeight(double height) {
		this.height = height;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGlucoseLevel() {
		return glucoseLevel;
	}
	public void setGlucoseLevel(String glucoseLevel) {
		this.glucoseLevel = glucoseLevel;
	}
	public String getDiabeticsLevel() {
		return diabeticsLevel;
	}
	public void setDiabeticsLevel(String diabeticsLevel) {
		this.diabeticsLevel = diabeticsLevel;
	}
	
	
}
