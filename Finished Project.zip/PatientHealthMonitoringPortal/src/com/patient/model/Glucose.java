package com.patient.model;

public class Glucose {
private int patientId;
private String timeOfTheDay;
private String bloodGlucoseLevel;
public int getPatientId() {
	return patientId;
}
public void setPatientId(int patientId) {
	this.patientId = patientId;
}
public String getTimeOfTheDay() {
	return timeOfTheDay;
}
public void setTimeOfTheDay(String timeOfTheDay) {
	this.timeOfTheDay = timeOfTheDay;
}
public String getBloodGlucoseLevel() {
	return bloodGlucoseLevel;
}
public void setBloodGlucoseLevel(String bloodGlucoseLevel) {
	this.bloodGlucoseLevel = bloodGlucoseLevel;
}

}
